import React from 'react';
import { render } from 'react-dom';
import Example from './components/Example';

render(<Example />, document.getElementById('root'));
