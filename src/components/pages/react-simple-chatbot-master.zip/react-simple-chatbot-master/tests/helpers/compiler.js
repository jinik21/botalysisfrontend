function noop() {
  return null;
}

require.extensions['.mp3'] = noop;
